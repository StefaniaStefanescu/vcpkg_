#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include<dirent.h>
#include<pthread.h>

#define MAX_WORD_LEN 100
#define WORDS 10


struct word_count {
    char word[MAX_WORD_LEN];
    int count=0;
    
};
int countNumberOfWords(const char* filename) {
    int count = 0;
    char currentChar;
    FILE* file = fopen(filename, "r");

    if (file == NULL) {
        printf("Could not open file: %s\n", filename);
        return -1;
    }

    while ((currentChar = fgetc(file)) != EOF) {
        if (currentChar == ' ' || currentChar == '\n' || currentChar == '\t') {
            count++;
        }
    }
    fclose(file);
    return count;
}
int countFilesFromDirectory(const char* directory)
{
    int count=0;
    DIR* dir;
    struct dirent* ent;
    if ((dir = opendir(directory)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if (ent->d_type == DT_REG) {
                char file_path[512];
                sprintf(file_path, "%s/%s", directory, ent->d_name);
                //printf("Filepath: %s\n", file_path);
              
               count++;
            }
        }
        closedir(dir);
    }
    else {
        perror("could not open the directory");
    }
    return count;
}
int compare_word_counts(const void* a, const void* b) {
    return ((struct word_count*)b)->count - ((struct word_count*)a)->count;
}

void extract_frequent_words(const char* file_name, struct word_count* frequent_words) {
   
    const int wordsNo = countNumberOfWords(file_name);
    struct word_count* word_counts=(struct word_count*)malloc(wordsNo*sizeof(struct word_count));
    
    int num_words = 0;
    char word[MAX_WORD_LEN];
    FILE* file = fopen(file_name, "r");
    if (file == NULL) {
        printf("Error opening file %s!\n", file_name);
        return;
    }
  
    while (fscanf(file, "%s", word) != EOF && num_words<wordsNo) {
        int i;
        for (i = 0; i < num_words; i++) {
            if (strcmp(word_counts[i].word, word) == 0) {
                word_counts[i].count++;
                break;
            }
        }
        if (i == num_words) {
            
            if (word != NULL)
            {
                strcpy(word_counts[num_words].word, word);
                word_counts[num_words].count = 1;
                num_words++;
            }
        }
    }

    fclose(file);
    if (word_counts)
    {
        qsort(word_counts, num_words, sizeof(struct word_count), compare_word_counts);
    }
    for (int i = 0; i < WORDS; i++) {
        if (word_counts[i].word)
        {
            strcpy(frequent_words[i].word, word_counts[i].word);
        }
        frequent_words[i].count = word_counts[i].count;
    }
}
struct file {
    char* file_name;
    int read_flag=0;
    int write_flag=0;
    struct word_count word_counts[WORDS];
};
void init_file(struct file* file_struct, const char* file_name) {
    
   
    file_struct->file_name = (char*)malloc(strlen(file_name)+1);
    if (file_struct->file_name && file_name)
    {
        strcpy(file_struct->file_name, file_name);
    }
    
    file_struct->read_flag = 0;
    file_struct->write_flag = 0;
    for (int i = 0; i < WORDS; i++) {
       file_struct->word_counts[i].count = 0;

       memset(file_struct->word_counts[i].word, 0, sizeof(file_struct->word_counts[i].word));
    }
    extract_frequent_words(file_struct->file_name, file_struct->word_counts);
}
void print_file(const struct file* file_struct) {
    printf("File name: %s\n", file_struct->file_name);
    printf("Read flag: %d\n", file_struct->read_flag);
    printf("Write flag: %d\n", file_struct->write_flag);
    printf("Word counts: \n");
    for (int i = 0; i < WORDS-1; i++) {
        if (file_struct->word_counts[i].count == 0) break;
        printf("Word: %s Count: %d\n", file_struct->word_counts[i].word, file_struct->word_counts[i].count);
    }
}
struct manager {
    char* directory_name;
    struct file* files;
    int num_files=0;
};
void scan_directory(struct manager* manager_struct) {
    DIR* dir;
    struct dirent* ent;
    int i = 0;
    if ((dir = opendir(manager_struct->directory_name)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if (ent->d_type == DT_REG) {
                char file_path[512];
                sprintf(file_path, "%s/%s", manager_struct->directory_name, ent->d_name);
                printf("Filepath: %s\n", file_path);
                init_file(&manager_struct->files[i], file_path);
                i++;
            }
        }
        closedir(dir);
    }
    else {
        perror("could not open the directory");
    }
}


void init_manager(struct manager* manager_struct, const char* directory_name,int filesNo) {
    if (directory_name != NULL) {
        manager_struct->directory_name = (char*)malloc(strlen(directory_name)+1);
        manager_struct->num_files = filesNo;
        manager_struct->files = (struct file*)malloc(filesNo * sizeof(struct file));
        printf("S-au alocat %d structuri de fisier pentru manager\n",filesNo);
        strcpy(manager_struct->directory_name, directory_name);
        scan_directory(manager_struct);

    }
    else {
        perror("Empty directory name:");
    }
    return;
   
}

struct server {
    int PORT;
    char* ROOT;
    int THREADS_NUMBER;
    char* NAME;
};
int init_server(const char* filename, struct server* server) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open config file: %s\n", filename);
        return -1;
    }

    char line[256];
    char key[256];
    char value[256];

    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%[^=]=%s", key, value);

        if (strcmp(key, "name") == 0) {
            snprintf(server->NAME, sizeof(server->NAME), "%s", value);
        }
        else if (strcmp(key, "port") == 0) {
            server->PORT = atoi(value);
        }
        else if (strcmp(key, "max_connections") == 0) {
            server->THREADS_NUMBER = atoi(value);
        }
    }

    fclose(file);
    return 0;
}


int main() {

   /* struct file my_file;
    init_file(&my_file, "C:/Users/Asus/OneDrive/Desktop/Anul 3/PSOP/Livrabil 1.pdf");
    print_file(&my_file);*/
    struct manager my_manager;
    int filesno = countFilesFromDirectory("C:/Users/Asus/OneDrive/Desktop/Anul 3/PSO/Fisiere");
    init_manager(&my_manager, "C:/Users/Asus/OneDrive/Desktop/Anul 3/PSO/Fisiere",filesno);
    for (int i = 0; i < my_manager.num_files; i++) {
        print_file(&my_manager.files[i]);
    }

    return 0;
}
